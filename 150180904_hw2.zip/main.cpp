/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/

//for compile and run
///////////////////////////
//g++ -std=c++11 main.cpp
//./a.out m p
///////////////////////////


#include <iostream>
#include <cmath>
#include <time.h>
#include <iomanip>
#include <chrono>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <string>

using namespace std;



void my_delete(vector<double>& my_heap){
    int len = my_heap.size();                   //len
    int index = len-1;                          // index is the index of last element
    my_heap[1] = my_heap[index];                // instead of remove the root just change its value to the last element of heap
    my_heap.pop_back();                         // and just pop the last element because it is duplicate of root now
    len--;                                      // decrement len
    index--;                                    // and index after pop operation
    int i = 1;
    while(1){
      if(2*i+1<=index){                         // if this is true means that this parent has the right child and if it has right so it has left child
        if(my_heap[i]>my_heap[2*i] && my_heap[i]>my_heap[2*i+1]){       // check which child has smaller value
          if(my_heap[2*i]<my_heap[2*i+1]){                              // if left then swap with the paren
            double t = my_heap[i];
            my_heap[i] = my_heap[2*i];
            my_heap[2*i] = t;
            i = 2*i;                                                    //update i
          }else{                                // if right is smaller then swap right child with parent
            double t = my_heap[i];
            my_heap[i] = my_heap[2*i+1];
            my_heap[2*i+1] = t;
            i = 2*i+1;                          //update i
          }
        }else if(my_heap[i]>my_heap[2*i+1]){                //else if only right child is smaller then just swap with it
          double t = my_heap[i];
          my_heap[i] = my_heap[2*i+1];
          my_heap[2*i+1] = t;
          i = 2*i+1;                                        // update i
        }else if(my_heap[i]>my_heap[2*i]){                  // else if only left child is smaller then just swap with it
          double t = my_heap[i];
          my_heap[i] = my_heap[2*i];
          my_heap[2*i] = t;
          i = 2*i;                                          //update i
        }else{
          break;                                            // if none of them is smaller means it is in appropreate place so just break
        }
      }else if(2*i<=index){                                 // if it has no right child check left child
        if(my_heap[i]>my_heap[2*i]){                        // if it is smaller then swap
          double t = my_heap[i];
          my_heap[i] = my_heap[2*i];
          my_heap[2*i] = t;
          i = i*2;                                          //update i
        }else{                                              // if not means it is in appropreate index so just break
          break;
        } 
      }else{                                                // if it has no child node then break
        break;
      }
 
    }
}


void my_insert(vector<double>& my_heap){
    int len = my_heap.size();               //len
    int index = len-1;                      // index is the index of last element in heap
    while(index>=1){                        //while index is greater than or equal to one means there is parent to check for proper index of new added element

        if(index%2==1){                     //if it is odd means it is right child of parent
            if((index-1)/2>=1 && my_heap[index]<my_heap[(index-1)/2]){      // and if its parent is greater then swap
                double t = my_heap[(index-1)/2];
                my_heap[(index-1)/2] = my_heap[index];
                my_heap[index] = t;
                index = (index-1)/2;                                        //update index value
            }else{                                                          // else just break
              break;
            }
        }else if(index%2==0){                // if it is even means it is left child of its parent
            if((index/2)>=1 && my_heap[index]<my_heap[index/2]){            //and if parent is greater swap
                double t = my_heap[index/2];
                my_heap[index/2] = my_heap[index];
                my_heap[index] = t;
                index = (index)/2;                                          //update the index
            }else{                                                          // else just break
              break;
            }
        }else{                          //useless check
            break;
        }
    }

}

int main(int argc, char**argv){

	ifstream file;
	file.open("locations.txt");

	if (!file) {                            //openning file
		cerr << "File cannot be opened!";
		exit(1);
	}
    string line;
    getline(file, line);                    //this is the header line

    int m = stoi(argv[1]);                  //total number of operations;
    double p = stod(argv[2]);               //probability
    vector <double> my_heap;                // my_heap data structure
    int num_of_taxi_additions=0;            // num of taxi addition operations
    int num_of_distance_updates=0;          // num of distance update operations
    srand (time(NULL)); 
    my_heap.push_back(0);                   // push back 0, so that my distances can be added started from index=1 so its children will be 2n and 2n+1
    int num_of_operations;                  //checks if number of operations is 100, reset it and call the taxi 

	cout << fixed << setprecision(9) << left;		
	auto start = chrono::high_resolution_clock::now();      // this is for running time calculation
    while(m>0){
        if (rand()/(double)RAND_MAX <= p){                  // checking the probability
            m--;                                            
            if(my_heap.size()!=1){                          // checkign if there is any taxi or not
                int index = my_heap.size()-1;
                int random_index = (rand()%(index))+1;      // my random index must be between 1 and the last index, because index 0 storing 0 that I added at the beginning of program
                num_of_distance_updates++;                  // increment number of distance update 

                num_of_operations++;
                my_heap[random_index] = my_heap[random_index]-0.01;     //decrement distance by 0.01
                if(my_heap[random_index]<0){                            // there was 1 case so the distance becomes -0.01 asistant write from ninova to set it 0
                    my_heap[random_index]=0;
                }
                while(1){
                    if(random_index>=1){                //while random index is bigger than 1, means if there is distance or not

                        if(random_index%2==1){          // I am checking if the index is odd means it is right child so can be accessed its parent by (random_index-1)/2
                            
                            if(my_heap[random_index]<my_heap[(random_index-1)/2] && (random_index-1)/2>=1){        // if its parent is bigger swap until smaller
                                double t = my_heap[(random_index-1)/2];
                                my_heap[(random_index-1)/2] = my_heap[random_index];
                                my_heap[random_index] = t;
                                random_index = (random_index-1)/2;
                            }else{                                                                                  // else just break
                                break;
                            }
                        }else{                           // if the random_index is even means it is the left child of its parent so can be accessed to left childs parent by random_index
                            if(my_heap[random_index]<my_heap[random_index/2] && random_index/2 >= 1){ // if then swap
                                double t = my_heap[random_index/2];
                                my_heap[random_index/2] = my_heap[random_index];
                                my_heap[random_index] = t;
                                random_index = random_index/2;
                            }else{                                                                      // if not break
                                break;
                            }                
                        }

                    }else{                                                              // if random_index is 0 break
                        break;
                    }
                    
                }
            }else{
                continue;                                                               // if there is no taxi distance just continue
            }
        }else{

            file>>line;									//
		    double longitude = stod(line);              // read value and convert

            file>>line;
            double	latitude = stod(line);              // read value and convert

            double distance = sqrt((longitude-33.40819)*(longitude-33.40819) + (latitude-39.19001)*(latitude-39.19001)); //calculate distance 

            num_of_taxi_additions++;            //increment number of taxis
            my_heap.push_back(distance);        // add it to vector and 
            my_insert(my_heap);

            m--;                                //decremwnt m
            num_of_operations++;                // increment number of operations
        }
        if(num_of_operations==100){
            //cout<<my_heap[1]<<" is the distance of called taxi"<< endl;
            my_delete(my_heap);
            m--;
            num_of_operations = 0;
        }
    }
    //cout<<num_of_taxi_additions<<" is number of taxi additions"<<endl;
    //cout<<num_of_distance_updates<<" is number of distance updates"<<endl;
	auto end = chrono::high_resolution_clock::now();
	chrono::duration<double> diff = end - start;
    cout << setw(9) << diff.count() << " s\n";
    file.close();



    return 0;
}
