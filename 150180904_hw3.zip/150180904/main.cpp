/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/

//for compile and run
///////////////////////////
//g++ -std=c++11 150180904.cpp -o 150180904
//./150180904 euroleague.csv
//./150180904 sample.csv
///////////////////////////

#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <chrono>
#include <time.h>

using namespace std;

class Node{//Node object
public:
    bool is_red;// if 1 means it is red, else black
    string season;
    string name;//store name
    string team;//store team
    int rebound;//store rebound 
    int assist;// strore assist
    int point;//  strore point
    Node* parent;// pointer to parent node
    Node* leftchild;// pointer to leftchild node
    Node* rightchild;// pointer to rightchild node
    Node(){// constructor
        parent=NULL;//set NULL
        leftchild=NULL;//set NULL
        rightchild=NULL;// set NULL
        is_red = 1;     // initially all nodes are red before insertion
    }
    ~Node(){};    //destructor

};

class List{   //list object stores headptr, emp string which stores "-"s, and it is containing function declerations  
public:
  Node* headptr;
  string emp;
  string my_st;
  Node* max_point;  //pointer to object with max point
  Node* max_assist; //pointer to object with max assist
  Node* max_rebound;//pointer to object with max rebound

  void insert_red_black(Node*);
  void LL_rotation(Node*, Node*, Node*);
  void LR_rotation(Node*, Node*, Node*);
  void RR_rotation(Node*, Node*, Node*);
  void RL_rotation(Node*, Node*, Node*);
  void my_print_all(Node*);
  void max_rebound_finder( Node*);
  void max_assist_finder(Node*);
  void max_point_finder(Node*);
  void my_delete(Node*); 
  List(){           //constructor
    headptr = NULL; //set to NULL
    my_st = "-";    // set to "-", I will append it to emp string  or pop from the emp as needed 
    max_point = NULL;//set to NULL
    max_assist = NULL;//set to NULL
    max_rebound =NULL;// set to NULL
  }
  ~List(){};      //destructor
};

void List::my_delete(Node* tmp){    //deletes nodes at the end  
  if(tmp==NULL){                    // if null just return
    return;
  }
  
  
  my_delete(tmp->leftchild);    //go to leftchild till it is null 

  my_delete(tmp->rightchild);   //go to rightchild till it is null
  delete tmp;                   // delete node
}


void List::max_rebound_finder(Node* mover){   //find max rebound node
  if(mover==NULL){                            //if null just return
    return;
  }else if(max_rebound->rebound<mover->rebound){  //else check if rebound is less in max_rebound than mover
    max_rebound = mover;                          // set mover to max_rebound
  }
  max_rebound_finder( mover->leftchild);          // check leftchild till it is null

  if(max_rebound->rebound<mover->rebound){        //if revound is less in max_rebound than mover
    max_rebound = mover;                          // set mover to max_rebound
  }
  max_rebound_finder( mover->rightchild);         //check rightchild

}

void List::max_assist_finder( Node* mover){    //find max assist
  if(mover==NULL){                              //if null just return
    return;
  }else if(max_assist->assist<mover->assist){   // else check if assist is less in max_assist than mover
    max_assist = mover;                         // set mover to max_assist
  }
  max_assist_finder( mover->leftchild);       // check letfchild till it is null
  if(max_assist->assist<mover->assist){       //if assist is less in max_assist than mover
    max_assist = mover;                       // set mover to max_assist
  }
  max_assist_finder( mover->rightchild);      // check rightchild

}


void List::max_point_finder( Node* mover){    //find max point
  if(mover==NULL){                            // if null just return
    return;
  }else if(max_point->point<mover->point){    //else check if point is less in max_point than mover 
    max_point = mover;                        // set mover to max_point
  }
  max_point_finder(mover->leftchild);         //check leftchild till it is null
  if(max_point->point<mover->point){          //if assist is less in max_point than mover
    max_point = mover;                        // set mover to max_point
  }
  max_point_finder(mover->rightchild);        //check rightchild till it is null

}


void List::my_print_all(Node* leafs){   //print tree
  if(leafs==NULL){                      //if null just return
    return;
  }
  
  for(long unsigned int i=0; i<emp.length();i++){   //print all "-"s in emp
    cout<<"-";
  }

  if(leafs->is_red){    //if is_red is 1, print red
    cout<<"(RED) ";     // print red 
  }else{                // else
    cout<<"(BLACK) ";   //print black
  }
  
  cout<<leafs->name<<endl;    //print name

  if(leafs->leftchild!=NULL){   //if leftchild is not null
    emp.append(my_st);          //append "-"
    my_print_all(leafs->leftchild); // go to leftchild
    if(emp.length()!=0){            //if length is not 0
      emp.pop_back();               //pop "-" when returning
    }
  }
  if(leafs->rightchild!=NULL){  // if rightchild is not null
    emp.append(my_st);          //append "-"
    my_print_all(leafs->rightchild);//go to the rightchild
    if(emp.length()!=0){            // if length is not 0
      emp.pop_back();               // pop "-" when returning
    }
  }

}




void List::LL_rotation(Node* grandparent, Node* parent, Node* myptr){   //do LL rotation
    Node* parent_right = parent->rightchild;          //stores rightchild subtree of parent
    parent->rightchild = grandparent;                 //parent's rightchild will be grandparent
    grandparent->leftchild = parent_right;            //grandparent's leftchild will be parent's right subtree
    parent->parent = grandparent->parent;             //parent's parent will be grandparent's parent
    if(parent->parent !=NULL){                        // if parent's parent is not NULL 
      if(parent->parent->rightchild==grandparent){    // if grandparent is parent's parent's rightchild then
        parent->parent->rightchild = parent;          //make parent's parent's rightchild parent
      }else{                                          //else
        parent->parent->leftchild = parent;           //make parent's parent's leftchild parent
      }
    }
    grandparent->parent = parent;                     //grandparent's parent will be parent
    if(parent_right!=NULL){                           //if parent_right subtree is not null 
      parent_right->parent = grandparent;             // make grandparent its parent
    }
    bool my_red = grandparent->is_red;                //swap grandparent's and parent's colours
    grandparent->is_red = parent->is_red;
    parent->is_red = my_red;
    if(grandparent==headptr){                         // if grandparent is headptr, then move grandparent
        headptr = parent;                             //set parent to headptr
    }
}

void List::LR_rotation(Node* grandparent, Node* parent, Node* myptr){   // LR rotation
    Node* myptr_left = myptr->leftchild;              //stores leftchild subtree of newly added node, I call it with myptr
    grandparent->leftchild = myptr;                   //grandparent's leftchild will be myptr
    myptr->parent = grandparent;                      //myptr's parent will be grandparent
    myptr->leftchild = parent;                        //myptr's leftchild will be parent
    parent->rightchild = myptr_left;                  // parent's rightchild will be left subtree named as myptr_left
    if(myptr_left!=NULL){                             // if myptr_left is not null
      myptr_left->parent = parent;                    //connect it to tree by assigning its parent to parent
    }
    parent->parent = myptr;                           //parent's parent will be myptr
    LL_rotation(grandparent, myptr, parent);          // then everything is same with LL rotation , so I can call LL rotation
                                                      //but I must be carefull, because myptr isnow parent and parent is its child now
}

void List::RR_rotation(Node*grandparent, Node*parent, Node*myptr){    // do RR rotation
    Node* parent_left = parent->leftchild;            // stores parent's left subtree  in parent_left
    parent->leftchild = grandparent;                  //parent's leftchild will be grandparent
    parent->parent = grandparent->parent;             // parent's parent will be grandparent
    if(parent->parent!=NULL){                         // if parent's parent is not NULL
      if(parent->parent->rightchild==grandparent){    // if parent's parents's rightchild is grandparent
        parent->parent->rightchild = parent;          // then do parent's parent's rightchild parent
      }else{                                          // else
        parent->parent->leftchild = parent;           // parent's parent's leftchild will be parent
      }
    }
    grandparent->parent = parent;                     // grandparent's parent will be parent
    grandparent->rightchild = parent_left;            // grandparent's rightchild will be parent_left
    if(parent_left!=NULL){                            // if parent_left is not NULL 
      parent_left->parent = grandparent;              // parent_left's parent will be grandparent
    }
    bool my_red = grandparent->is_red;                // swap the colours of grandparent and parent
    grandparent->is_red = parent->is_red;
    parent->is_red = my_red;
    if(grandparent==headptr){                         // if grandparent was headptr
        headptr = parent;                             // then move headptr to parent, because it is at the top of tree after rotation
    }

}


void List::RL_rotation(Node*grandparent, Node*parent, Node*myptr){  // RL rotation
    Node* myptr_right = myptr->rightchild;           //newly added node in tree which is called myptr. stores my_ptr's rightchild in myptr_right
    grandparent->rightchild = myptr;                 //grandparent's rightchild will be myptr
    myptr->parent = grandparent;                     //myptr's parent will be grandparent
    myptr->rightchild = parent;                      //myptr's rightchild will be parent
    parent->leftchild = myptr_right;                 //parent's rightchild will be myptr_right
    if(myptr_right!=NULL){                           //if myptr_right is not NULL
      myptr_right->parent = parent;                  //then myptr_right's parent will be parent
    }
    parent->parent = myptr;                          //parent's parent will be myptr
    RR_rotation(grandparent, myptr, parent);         //everything after that point will be RR rotation, so I can call it. I should be very carefull, because now myptr is parent and parent is myptr

}

void List::insert_red_black(Node* newnode){                           // doing insertion
    Node* myptr = newnode;                           //myptr will point ot newly added node
    bool is_update = false;                          // is_update is not initially, if it will be update operation not insertion, this bool variable will be true
    if(headptr!=NULL){                               // if it is not first node adding to tree
        Node* traverse = headptr;                    // traverse point to headptr
        while(1){                                    // while 1 
            if(traverse->rightchild==NULL && traverse->leftchild==NULL){  // if both childs are null
                if(traverse->name > myptr->name){                         // check if its name has less ascii number then make myptr leftchild
                    traverse->leftchild = myptr;
                    myptr->parent = traverse;                             // and myptr's parent traverse
                }else if(traverse->name < myptr->name){                   //else if its name has bigger ascii number then make myptr rightchild
                    traverse->rightchild = myptr;
                    myptr->parent = traverse;                             // and myptr's parent traverse
                }else{
                    traverse->season = myptr->season;                     // else they are equal means it is update
                    traverse->name = myptr->name;                         //update variables
                    traverse->team = myptr->team;
                    traverse->rebound += myptr->rebound;
                    traverse->assist += myptr->assist;
                    traverse->point += myptr->point;
                    delete myptr;                                         //delete because I did not add node to tree
                    is_update = true;                                     // make is_update true
                }
                break;        //break
            }

            if(traverse->name  > myptr->name){                            // check if its name has less ascii number then make myptr leftchild
                if(traverse->leftchild != NULL){                          // if its letfchild is not NULL move left
                    traverse = traverse->leftchild;
                }else{                                                    // else add to the left
                    traverse->leftchild = myptr;
                    myptr->parent = traverse;                             //myptr's parent is traverse
                    break;                                                // after addition break
                }
            }else if(traverse->name < myptr->name){                       //else if its name has bigger ascii number then make myptr rightchild
                if(traverse->rightchild != NULL){                         //if rightchild is not NULL
                    traverse = traverse->rightchild;                      //move to rightchild
                }else{                                                    //else add to the right
                    traverse->rightchild = myptr;
                    myptr->parent = traverse;                             //myptr's parent is traverse
                    break;      //break
                }
            }else{                                                        // they are equal, so do update opeartion
              traverse->season = myptr->season;                           // update contents
              traverse->name = myptr->name;
              traverse->team = myptr->team;
              traverse->rebound += myptr->rebound;
              traverse->assist += myptr->assist;
              traverse->point += myptr->point;
              is_update = true;                                           // make is_update true
              delete myptr;                                               // delete because we did not add node to the tree
              break;                                                      // tree
            }
        }

    }else{
        headptr = newnode;                                                // if headptr is NULL, means it is first node in the tree. so assigh it to headptr

    }

    if(headptr==myptr){                                                   // if it is headptr just make it black.
        myptr->is_red=0;
    }else{                                                                // else
        while(myptr->parent!=NULL && is_update!=true){
            if(myptr->parent->is_red==1){   // if parent node is red
                if(myptr->parent->parent!=NULL&& (myptr->is_red==1 && myptr->parent->is_red==1)){ // if grandparent is not NULL and (newly added node and its parent is red)
                    Node* tmp = myptr;                                     //tmp points to newly added node
                    tmp = tmp->parent->parent;                             // reach to grandparent in order to reach uncle
                    if(tmp->rightchild!=NULL){                              //check rightchild
                        if(tmp->rightchild->name == myptr->parent->name){   // if my parent is rightchild of grandparent then check the leftchild of grandparent for uncle
                            if(tmp->leftchild!=NULL){                       //if leftchild is not NULL, tmp has uncle, else tmp does not have uncle so uncle colour is black, because uncle is NULL
                                tmp = tmp->leftchild;                       //move to uncle, so tmp points to uncle now
                                if(tmp->is_red==1){                         // if uncle is red
                                    myptr->parent->is_red = 0;              //make parent
                                    tmp->is_red = 0;                        //and uncle's colour black
                                    tmp->parent->is_red=1;                  // and grabdparent red
                                    if(tmp->parent!=headptr){               // check if grandparent is not headptr
                                      myptr = tmp->parent;                  // move for checking above nodes
                                    }
                                    
                                }else{                                      //if uncle is not red do some rotation
                                    //rotation
                                    Node* grandparent = tmp->parent;        //granparent points to grandparent node 
                                    if(grandparent->rightchild==myptr->parent && grandparent->rightchild->rightchild==myptr){// if it is RR
                                      //call_RR();
                                        RR_rotation(grandparent, myptr->parent, myptr); //call RR
                                        if(myptr->parent!=NULL){                        //move myptr in order to check other nodes above
                                          myptr = myptr->parent;
                                        }
                                    }else if(grandparent->rightchild==myptr->parent && grandparent->rightchild->leftchild==myptr){// if it is RL
                                        //call_RL();
                                        RL_rotation(grandparent, myptr->parent, myptr);//call RL
                                        if(myptr->parent!=NULL){                       //move myptr in order to check other nodes above
                                          myptr = myptr->parent;
                                        }
                                    }
                                }
                            }else{                                          //if uncle is NULL, means its colour is black. So rotation needed
                                //rotation
                                Node* grandparent = tmp;
                                if(grandparent->rightchild==myptr->parent && grandparent->rightchild->rightchild==myptr){// if it is RR
                                  //call_RR();
                                        RR_rotation(grandparent, myptr->parent, myptr);   //call RR
                                        if(myptr->parent!=NULL){                          //move myptr in order to chack other nodes above
                                          myptr = myptr->parent;
                                        }
                                }else if(grandparent->rightchild==myptr->parent && grandparent->rightchild->leftchild==myptr){ // if it is RL
                                  //call_RL();
                                        RL_rotation(grandparent, myptr->parent, myptr);   //call RL
                                        if(myptr->parent!=NULL){                          // move myptr in order to chack other nodes above
                                          myptr = myptr->parent;
                                        }
                                }
                            }
                        }else if(tmp->leftchild->name== myptr->parent->name){             // if parent is grandparent's leftchild
                            if(tmp->rightchild!=NULL){                                    //check rightchild for uncle
                                tmp = tmp->rightchild;                      // if it is not NULL, move there. So tmp points to uncle now
                                if(tmp->is_red==1){                         // if uncle's colour is red, no rotation is needed
                                    myptr->parent->is_red=0;                // change parent's 
                                    tmp->is_red = 0;                        // and uncle's colour to black
                                    tmp->parent->is_red=1;                  // change grandparent to red
                                    if(tmp->parent!=NULL){                  // if it is not NULL check above nodes
                                      myptr = tmp->parent;
                                    }
                                }else{                                      // if uncle's colour is black, rotation is needed
                                    //rotation
                                    Node* grandparent = tmp->parent;
                                    if(grandparent->leftchild==myptr->parent && grandparent->leftchild->leftchild==myptr){//if it is LL
                                      //call_LL();
                                        LL_rotation(grandparent, myptr->parent, myptr);//call LL
                                        if(myptr->parent!=NULL){                        //move for checking above nodes, if its parent is not NULL
                                          myptr = myptr->parent;
                                        }                                        
                                    }else if(grandparent->leftchild==myptr->parent && grandparent->leftchild->rightchild==myptr){// if it is LR
                                        //call_LR
                                        LR_rotation(grandparent, myptr->parent, myptr);//call LR
                                        if(myptr->parent!=NULL){                        //move for checking above nodes, if its parent is not NULL
                                          myptr = myptr->parent;
                                        }
                                    }                                      
                                }

                            }else{                                          //if rightchild is NULL then it means uncle is black 
                                //rotation
                                Node* grandparent = tmp;                    //So tmp points to grandparent
                                if(grandparent->leftchild==myptr->parent && grandparent->leftchild->leftchild==myptr){ //if it is LL
                                    //call_LL();
                                        LL_rotation(grandparent, myptr->parent, myptr);//call LL
                                        if(myptr->parent!=NULL){                      //move myptr for checking above nodes
                                          myptr = myptr->parent;
                                        }
                                }else if(grandparent->leftchild==myptr->parent && grandparent->leftchild->rightchild==myptr){// if it is LR
                                    //call_LR
                                        LR_rotation(grandparent, myptr->parent, myptr);// call LR //deyisdirdim.
                                        if(myptr->parent!=NULL){
                                          myptr = myptr->parent;
                                        }
                                }                                
                            }
                        }
                    }else if(tmp->leftchild!=NULL){           // if leftchild is not NULL
                        if(tmp->leftchild->name == myptr->parent->name){// else check rightchild for uncle
                            if(tmp->rightchild!=NULL){          // if rightchild is not NULL
                                tmp = tmp->rightchild;          //move to the right
                                if(tmp->is_red==1){             // if uncle's colour is red, no need for rotation
                                    myptr->parent->is_red = 0;  // change parent's
                                    tmp->is_red=0;              //uncle's colour to black
                                    tmp->parent->is_red=1;      //and grandparent's colour to red
                                    if(tmp->parent!=NULL){      // move for checking nodes above
                                      myptr = tmp->parent;
                                    }
                                }else{                          //else do rotation
                                    //rotation
                                    Node* grandparent = tmp->parent;
                                    if(grandparent->leftchild==myptr->parent && grandparent->leftchild->leftchild==myptr){ //if it is LL
                                        //call_LL();
                                        LL_rotation(grandparent, myptr->parent, myptr);//call LL
                                        if(myptr->parent!=NULL){
                                          myptr = myptr->parent;
                                        }
                                    }else if(grandparent->leftchild==myptr->parent && grandparent->leftchild->rightchild){// if it is LR
                                        //call_LR
                                        LR_rotation(grandparent, myptr->parent, myptr);       //call LR
                                        if(myptr->parent!=NULL){                            //move for  checking other nodes above
                                          myptr = myptr->parent;
                                        }
                                    }
                                }
                            }else{        //do rotation
                                //rotation
                                Node* grandparent = tmp;
                                if(grandparent->leftchild==myptr->parent && grandparent->leftchild->leftchild==myptr){ //if it is LL
                                    //call_LL();
                                        LL_rotation(grandparent, myptr->parent, myptr);     //call LL
                                        if(myptr->parent!=NULL){
                                          myptr = myptr->parent;
                                        }
                                }else if(grandparent->leftchild==myptr->parent && grandparent->leftchild->rightchild==myptr){// if it is LR
                                        //call_LR
                                        LR_rotation(grandparent, myptr->parent, myptr);//call LR
                                        if(myptr->parent!=NULL){                        //move for checking nodes above
                                          myptr =myptr->parent;
                                        }
                                }
                            }
                        }/*else if(tmp->rightchild->name== myptr->parent->name){        // unnecessary control
                            if(tmp->leftchild!=NULL){
                                tmp = tmp->leftchild;
                                if(tmp->is_red==1){
                                    myptr->parent->is_red=0;
                                    tmp->is_red=0;
                                    tmp->parent->is_red=0;
                                }else{

                                }
                            }
                        }*/
                    }
                }else{
                    break;    //break

                }
            }else{      // if parent node is black
                break;// do not change
            }
        }
    }
    headptr->is_red=0;// make headptr black
    
    return;
}


int main(int argc, char**argv){

	  string my_filename = argv[1];//getting filename as argument
	  ifstream file;
	  file.open(my_filename);       //openning file 
	  
    if (!file) {
		  cerr << "File cannot be opened!";   //error if can not be opened
		  exit(1);
	  }

    List l;//object l type List
    string line;
  	getline(file, line); //this is the header line
	  string my_header = line;
    int i = 0;        // these are for checking when printing results
    bool is_first = 1;
    bool show_result = 0;
    string old_season;//storing old season
    string for_print;
    while(!(file.eof())){
        Node* newnode = new Node;
		    getline(file, line, ','); //season (string)									//
		    string my_season = line;
        if(old_season!=my_season){// checking season and deciding to print season results or not
          if(old_season==""){
            for_print = my_season;
            old_season = my_season;
          }else if(my_season!=old_season){
            if(for_print!=my_season&& is_first==1){
              i=1;
            }
            show_result=1;
          }
        }

        if(show_result==1){                               //if show_result is 1 print results
          cout<<"End of the "<<old_season<<" Season"<<endl;
          old_season = my_season;
          Node* mover = l.headptr;
          l.max_point = l.headptr;
          l.max_point_finder( mover);//check max point
          cout<<"Max Points: "<<l.max_point->point<<" - Player Name: "<<l.max_point->name<<endl;
          mover = l.headptr;
          l.max_assist = l.headptr;
          l.max_assist_finder( mover);//check max assist
          cout<<"Max Assists: "<<l.max_assist->assist<<" - Player Name: "<<l.max_assist->name<<endl;
          mover = l.headptr;
          l.max_rebound = l.headptr;
          l.max_rebound_finder(mover);// check max rebound
          cout<<"Max Rebs: "<<l.max_rebound->rebound<<" - Player Name: "<<l.max_rebound->name<<endl;
          show_result=0;
          if(i==1 && is_first==1){        // if it is firts seaon print tree
            Node* leafs = l.headptr;
            l.my_print_all(leafs);
            is_first=0;
          }
        }
        getline(file, line, ','); //item type (string)									//
		    string my_name = line;
		    getline(file, line, ','); //item type (string)									//
		    string my_team = line;
		    getline(file, line, ','); //item type (string)									//
		    int my_rebound = stoi(line);
		    getline(file, line, ','); //item type (string)									//
		    int my_assist = stoi(line);
		    getline(file, line, '\n'); //item type (string)									//
		    int my_point = stoi(line);        

        newnode->name = my_name;    //assign datas to newnode
        newnode->team = my_team;
        newnode->rebound = my_rebound;
        newnode->assist = my_assist;
        newnode->point = my_point;
        newnode->is_red = 1;
        l.insert_red_black(newnode);// insert to tree 
        if(file.eof()){             // print the last season at the end of file
          cout<<"End of the "<<my_season<<" Season"<<endl;
          Node* mover = l.headptr;
          l.max_point = l.headptr;
          l.max_point_finder( mover);// check max point
          cout<<"Max Points: "<<l.max_point->point<<" - Player Name: "<<l.max_point->name<<endl;
          mover = l.headptr;
          l.max_assist = l.headptr;
          l.max_assist_finder( mover);//check max assist
          cout<<"Max Assists: "<<l.max_assist->assist<<" - Player Name: "<<l.max_assist->name<<endl;
          mover = l.headptr;
          l.max_rebound = l.headptr;
          l.max_rebound_finder( mover);//cheack max rebound
          cout<<"Max Rebs: "<<l.max_rebound->rebound<<" - Player Name: "<<l.max_rebound->name<<endl;     
          l.my_delete(l.headptr);
        }
    }
    file.close();//close file
    return 0;
}