/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/

//for compile and run
///////////////////////////
//g++ -std=c++11 main.cpp
//./a.out N
///////////////////////////



#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <iomanip>
#include <chrono>
#include <time.h>

using namespace std;

class my_content {														// my object 
public:																	// it contains country name, item type, order id, units sold and total profit with asked data types in hw pdf.
	string country;
	string type;
	string Order_id;
	int Units_sold;
	float Total_profit;
	my_content() {};
	my_content(string read_country, string read_type, string read_order, int read_unit_sold, float read_total_profit);//constructor
	~my_content() {																									  // destructor
		//cout << "Object destructed" << endl;																		// additional lines used in debugging
	}

};

int give_part(my_content **arr, int first, int last)															// partition funtion I wrote it from pseudocode in slides
{
	string pivot = arr[last]->country;																		// pivot  is chosen as last object
	int i = (first - 1);																						// Index of smaller object  

	for (int j = first; j <= last - 1; j++)
	{
																											// If current objects value is smaller than the pivot's  
		if ((arr[j]->country.compare(pivot)) < 0)
		{
			i++; // increment index of smaller object  
			my_content *t = arr[i];						// I swap only addresses for decreasing runtime.
			arr[i] = arr[j];							//my_content *t stores address of object arr[i];
			arr[j] = t;									// so that we can swap them.
			
		}
		else if (arr[j]->country.compare(pivot) == 0) {														//If the current object's country name is same with pivot's
			if (arr[j]->Total_profit > arr[last]->Total_profit) {
				i++;
				my_content *t = arr[i];					// I swap only addresses for decreasing runtime.
				arr[i] = arr[j];						//my_content *t stores address of object arr[i];
				arr[j] = t;								// so that we can swap them.
			}
		}
	}
																											//swap operation to pass the pivot to its actual index in array
	my_content *t = arr[i + 1];
	arr[i + 1] = arr[last];
	arr[last] = t;
	return (i + 1);
}

void my_quicksort(my_content** arr, int first, int last)
{
	if (first < last)
	{

		int pi = give_part(arr, first, last);																//choosing partition


		my_quicksort(arr, first, pi - 1);																	//divide array as quick sort is divide and conquer algorithm
		my_quicksort(arr, pi + 1, last);
	}
}




my_content::my_content(string read_country, string read_type, string read_order, int read_unit_sold, float read_total_profit) {				//constructor
	//cout << "Object constructed" << endl;
	country = read_country;
	type = read_type;
	Order_id = read_order;
	Units_sold = read_unit_sold;
	Total_profit = read_total_profit;
}

int main(int argc, char**argv) {						//taking input from terminal

	ifstream file;
	file.open("sales.txt");																					//opening file

	if (!file) {
		cerr << "File cannot be opened!";
		exit(1);
	}

	int N = atoi(argv[1]);// = 1000000; //you should read value of N from command line						//setting N to value from terminal
	//cin >> N;
	my_content** my_arr = new my_content*[N];											// my array stores the addresses of objects. So that I can swap only addresses instead of object like linked list and decrease run time
	string line;

	getline(file, line); //this is the header line
	string my_header = line;
	for (int i = 0; i < N; i++) {

		getline(file, line, '\t'); //country (string)									//
		string read_country = line;
		getline(file, line, '\t'); //item type (string)									//
		string read_type = line;
		getline(file, line, '\t'); //order id (string)									//getting inputs from file
		string read_order = line;
		file >> line; //units sold (integer)											//
		int read_unit_sold = stoi(line);
		file >> line; //total profit (float)
		float read_total_profit = stof(line);											//
		getline(file, line, '\n'); //this is for reading the \n character into dummy variable.
	//cout<<read_country<<" "<< read_type<<" "<< read_order<<" "<<read_unit_sold<<" "<<read_total_profit<<endl;
		my_arr[i] = new my_content(read_country, read_type, read_order, read_unit_sold, read_total_profit);				//calling constructor.
	}
	file.close();																		//closing file
	cout << fixed << setprecision(9) << left;		
	auto start = chrono::high_resolution_clock::now();									//this line is for calculating runtime.
	my_quicksort(my_arr, 0, N - 1);														// calling quicksort
	//t = clock() - t;
	auto end = chrono::high_resolution_clock::now();
	chrono::duration<double> diff = end - start;
	//cout << fixed <<setprecision(7) << double(t) / CLOCKS_PER_SEC << endl;			//old code blocks which were not efficient for calculating run time
	//cout<<line<<endl;
	cout << setw(9) << diff.count() << " s\n";
	ofstream sorted_file("sorted.txt");													//opening sorted.txt to write result into it
	
	if (sorted_file.is_open()) {
		for (int j = 0; j < N; j++) {
			if (j == 0) {
				sorted_file << my_header<<endl;
			}
			sorted_file << my_arr[j]->country << "\t";						//
			sorted_file << my_arr[j]->type << "\t";							//
			sorted_file << my_arr[j]->Order_id << "\t";						//  Writing results to sorted.txt file
			sorted_file << my_arr[j]->Units_sold << "\t";					//
			sorted_file << my_arr[j]->Total_profit << endl;					//
		}
		sorted_file.close();												//closing file
	}
	else {
		cout << "The sorted.txt could not be opened" << endl;				//control if problem occured this will be printed in the terminal 
	}

	for (int i = 0; i < N; i++) {											//deleting allocated memory
		delete my_arr[i];
	}
	delete[] my_arr;														// deleting allocated memory for array
	return 0;
}